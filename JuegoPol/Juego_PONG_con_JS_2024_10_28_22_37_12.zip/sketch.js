let posicionPelotaX, posicionPelotaY;
let velocidadPelotaX = 6;
let velocidadPelotaY = 6;
let diametroPelota = 20;
let anguloPelota = 0; // Variable para el ángulo de rotación

// Variables para las raquetas
let anchoRaqueta = 10;
let altoRaqueta = 100;
let posicionRaquetaJugadorY;
let posicionRaquetaComputadoraY;
let velocidadRaquetaComputadora = 4;

// Tamaño de la pantalla
let anchoPantalla = 800;
let altoPantalla = 400;

// Tamaño del marco superior e inferior
let grosorMarco = 10;

// Variables para el puntaje
let puntajeJugador = 0;
let puntajeComputadora = 0;

// Variables para las imágenes y sonidos
let fondo, imagenRaquetaJugador, imagenRaquetaComputadora, imagenPelota;
let sonidoRebote; // Variable para el sonido de rebote
let sonidoGol; // Variable para el sonido al marcar gol

function preload() {
    fondo = loadImage("fondo1.png");
    imagenRaquetaJugador = loadImage("barra1.png");
    imagenRaquetaComputadora = loadImage("barra2.png");
    imagenPelota = loadImage("bola.png");
    sonidoRebote = loadSound("bounce.wav"); // Cargar el sonido de rebote
    sonidoGol = loadSound("game_over_mono.wav"); // Cargar el sonido de gol
}

function setup() {
    createCanvas(anchoPantalla, altoPantalla);
    inicializarPosiciones();
}

function draw() {
    background(fondo);
    dibujarMarcos();
    dibujarPelota();
    dibujarRaquetas();
    mostrarPuntaje();

    moverPelota();
    moverRaquetaJugador();
    moverRaquetaComputadora();

    comprobarReboteMarcos();
    comprobarColisionesRaquetas();
    reiniciarPelota();
}

function inicializarPosiciones() {
    posicionPelotaX = width / 2;
    posicionPelotaY = height / 2;
    posicionRaquetaJugadorY = height / 2 - altoRaqueta / 2;
    posicionRaquetaComputadoraY = height / 2 - altoRaqueta / 2;
    anguloPelota = 0; // Reinicia el ángulo de rotación al centro
}

function dibujarMarcos() {
    rect(0, 0, width, grosorMarco);
    rect(0, height - grosorMarco, width, grosorMarco);
}

function mostrarPuntaje() {
    fill(color("#2B3FD6"));
    textSize(32);
    textAlign(CENTER, TOP);
    text(puntajeJugador, width / 4, 20);
    text(puntajeComputadora, (3 * width) / 4, 20);
}

function dibujarPelota() {
    let velocidadTotal = sqrt(velocidadPelotaX * velocidadPelotaX + velocidadPelotaY * velocidadPelotaY);
    anguloPelota += velocidadTotal * 0.05; // Incrementa el ángulo en función de la velocidad

    push();
    translate(posicionPelotaX, posicionPelotaY); // Mueve el sistema de coordenadas a la posición de la pelota
    rotate(anguloPelota); // Aplica la rotación
    imageMode(CENTER); // Asegura que la imagen se dibuje desde el centro
    image(imagenPelota, 0, 0, diametroPelota, diametroPelota); // Dibuja la imagen rotada
    pop();
}

function dibujarRaquetas() {
    image(imagenRaquetaJugador, 10, posicionRaquetaJugadorY, anchoRaqueta, altoRaqueta);
    image(imagenRaquetaComputadora, width - 20, posicionRaquetaComputadoraY, anchoRaqueta, altoRaqueta);
}

function moverPelota() {
    posicionPelotaX += velocidadPelotaX;
    posicionPelotaY += velocidadPelotaY;
}

function moverRaquetaJugador() {
    if (keyIsDown(UP_ARROW)) {
        posicionRaquetaJugadorY -= 6;
    } else if (keyIsDown(DOWN_ARROW)) {
        posicionRaquetaJugadorY += 6;
    }
    posicionRaquetaJugadorY = constrain(posicionRaquetaJugadorY, grosorMarco, height - altoRaqueta - grosorMarco);
}

function moverRaquetaComputadora() {
    if (posicionPelotaY < posicionRaquetaComputadoraY + altoRaqueta / 2) {
        posicionRaquetaComputadoraY -= velocidadRaquetaComputadora;
    } else if (posicionPelotaY > posicionRaquetaComputadoraY + altoRaqueta / 2) {
        posicionRaquetaComputadoraY += velocidadRaquetaComputadora;
    }
    posicionRaquetaComputadoraY = constrain(posicionRaquetaComputadoraY, grosorMarco, height - altoRaqueta - grosorMarco);
}

function comprobarReboteMarcos() {
    if (posicionPelotaY - diametroPelota / 2 < grosorMarco || 
        posicionPelotaY + diametroPelota / 2 > height - grosorMarco) {
        velocidadPelotaY *= -1;
    }
}

function comprobarColisionesRaquetas() {
    // Colisión con la raqueta del jugador
    if (posicionPelotaX - diametroPelota / 2 < 20 &&
        posicionPelotaY > posicionRaquetaJugadorY && 
        posicionPelotaY < posicionRaquetaJugadorY + altoRaqueta) {
        reboteRaquetaJugador();
    } else if (posicionPelotaX - diametroPelota / 2 < 20) {
        // Ajuste para evitar que la pelota se quede atrapada en la raqueta y el borde
        if (posicionPelotaY <= grosorMarco || posicionPelotaY >= height - grosorMarco) {
            velocidadPelotaX *= -1; // Cambia de dirección horizontal
            velocidadPelotaY *= -1; // Cambia de dirección vertical para sacarla del borde
        }
    }

    // Colisión con la raqueta de la computadora
    if (posicionPelotaX + diametroPelota / 2 > width - 20 &&
        posicionPelotaY > posicionRaquetaComputadoraY && 
        posicionPelotaY < posicionRaquetaComputadoraY + altoRaqueta) {
        reboteRaquetaComputadora();
    } else if (posicionPelotaX + diametroPelota / 2 > width - 20) {
        // Ajuste para evitar que la pelota se quede atrapada en la raqueta y el borde
        if (posicionPelotaY <= grosorMarco || posicionPelotaY >= height - grosorMarco) {
            velocidadPelotaX *= -1; // Cambia de dirección horizontal
            velocidadPelotaY *= -1; // Cambia de dirección vertical para sacarla del borde
        }
    }
}

function reboteRaquetaJugador() {
    let impacto = posicionPelotaY - (posicionRaquetaJugadorY + altoRaqueta / 2);

    // Verificar si la raqueta del jugador está en el borde superior o inferior
    if (posicionRaquetaJugadorY <= grosorMarco || posicionRaquetaJugadorY >= height - altoRaqueta - grosorMarco) {
        let anguloRebote = map(impacto, -altoRaqueta / 2, altoRaqueta / 2, -PI / 4, PI / 4); // Ángulo más inclinado
        velocidadPelotaY = 10 * sin(anguloRebote);
        velocidadPelotaX *= -1.1; // Aumenta ligeramente la velocidad horizontal para que la pelota salga del borde
    } else {
        let anguloRebote = map(impacto, -altoRaqueta / 2, altoRaqueta / 2, -PI / 3, PI / 3);
        velocidadPelotaY = 10 * sin(anguloRebote);
        velocidadPelotaX *= -1;
    }

    sonidoRebote.play(); // Reproduce el sonido al rebotar en la raqueta del jugador
}

function reboteRaquetaComputadora() {
    let impacto = posicionPelotaY - (posicionRaquetaComputadoraY + altoRaqueta / 2);

    // Verificar si la raqueta de la computadora está en el borde superior o inferior
    if (posicionRaquetaComputadoraY <= grosorMarco || posicionRaquetaComputadoraY >= height - altoRaqueta - grosorMarco) {
        let anguloRebote = map(impacto, -altoRaqueta / 2, altoRaqueta / 2, -PI / 4, PI / 4); // Ángulo más inclinado
        velocidadPelotaY = 10 * sin(anguloRebote);
        velocidadPelotaX *= -1.1; // Aumenta ligeramente la velocidad horizontal para que la pelota salga del borde
    } else {
        let anguloRebote = map(impacto, -altoRaqueta / 2, altoRaqueta / 2, -PI / 3, PI / 3);
        velocidadPelotaY = 10 * sin(anguloRebote);
        velocidadPelotaX *= -1;
    }

    sonidoRebote.play(); // Reproduce el sonido al rebotar en la raqueta de la computadora
}


// Función para narrar el marcador actual
function narrarMarcador() {
    let narrador = new SpeechSynthesisUtterance();
    narrador.text = `Jugador ${puntajeJugador}, Computadora ${puntajeComputadora}`;
    narrador.lang = 'es-ES'; // Idioma español
    window.speechSynthesis.speak(narrador);
}

function reiniciarPelota() {
    if (posicionPelotaX < 0) {
        puntajeComputadora++;
        inicializarPosiciones();
        velocidadPelotaX *= -1;
        sonidoGameOver.play(); // Reproduce el sonido de gol
        narrarMarcador(); // Llama a la narración del nuevo marcador
    } else if (posicionPelotaX > width) {
        puntajeJugador++;
        inicializarPosiciones();
        velocidadPelotaX *= -1;
        sonidoGameOver.play(); // Reproduce el sonido de gol
        narrarMarcador(); // Llama a la narración del nuevo marcador
    }
}


function reiniciarPelota() {
    if (posicionPelotaX < 0) {
        puntajeComputadora++;
        sonidoGol.play(); // Reproduce el sonido cuando la computadora anota un gol
       narrarMarcador(); // Llama a la función de narración después de un gol
        inicializarPosiciones();
        velocidadPelotaX *= -1;
    } else if (posicionPelotaX > width) {
        puntajeJugador++;
        sonidoGol.play(); // Reproduce el sonido cuando el jugador anota un gol
        inicializarPosiciones();
        velocidadPelotaX *= -1;
    }
}
// Función para narrar el marcador con la API de SpeechSynthesis
function narrarMarcador() {
    let mensaje = `El marcador es, jugador ${puntajeJugador}, computadora ${puntajeComputadora}`;
    let narrador = new SpeechSynthesisUtterance(mensaje);
    narrador.lang = 'es-ES'; // Establece el idioma a español
    window.speechSynthesis.speak(narrador);
}